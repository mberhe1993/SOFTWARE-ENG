package edu.miu.cs.cs425.sweonlinemarketproject.constant;

public enum PaymentType {
    NONE,
    CREDIT,
    DEBIT
}
