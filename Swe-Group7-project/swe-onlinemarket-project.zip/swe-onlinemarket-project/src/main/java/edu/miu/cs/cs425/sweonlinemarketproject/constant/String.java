package edu.miu.cs.cs425.sweonlinemarketproject.constant;

public enum String {
    PENDING,
    SHIPPED,
    ON_THE_WAY,
    DELIVERED,
    CANCELLED,
    RETURNED
}
