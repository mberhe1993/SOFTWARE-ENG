package edu.miu.cs.cs425.sweonlinemarketproject.constant;

public enum RoleType {
    ADMIN,SELLER,BUYER
}
